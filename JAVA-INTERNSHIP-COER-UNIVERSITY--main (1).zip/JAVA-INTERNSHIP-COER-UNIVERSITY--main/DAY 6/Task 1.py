<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bank Withdrawal Checker</title>

<style>
body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#eef2ff;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.container{
    width:400px;
    background:#fff;
    padding:30px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.2);
}

h2{
    text-align:center;
    margin-bottom:25px;
}

label{
    display:block;
    margin-top:15px;
    font-weight:bold;
}

input,select{
    width:100%;
    padding:10px;
    margin-top:5px;
    border:1px solid #ccc;
    border-radius:5px;
    box-sizing:border-box;
}

button{
    width:100%;
    padding:12px;
    margin-top:20px;
    background:#0d6efd;
    color:white;
    border:none;
    border-radius:5px;
    font-size:16px;
    cursor:pointer;
}

button:hover{
    background:#0b5ed7;
}

#result{
    margin-top:20px;
    padding:12px;
    border-radius:5px;
    text-align:center;
    font-weight:bold;
}
</style>
</head>

<body>

<div class="container">
<h2>Bank Withdrawal Checker</h2>

<label>Current Balance (₹)</label>
<input type="number" id="balance" value="10000">

<label>Withdrawal Amount (₹)</label>
<input type="number" id="withdraw" value="5000">

<label>Account Type</label>
<select id="type">
    <option>Premium</option>
    <option>Regular</option>
</select>

<button onclick="checkWithdrawal()">Check Withdrawal</button>

<div id="result"></div>
</div>

<script>
function checkWithdrawal(){

let balance=parseFloat(document.getElementById("balance").value);
let amount=parseFloat(document.getElementById("withdraw").value);
let type=document.getElementById("type").value;
let result=document.getElementById("result");

let minBalance=(type==="Premium")?1000:500;

if(amount<=0){
    result.style.background="#f8d7da";
    result.innerHTML="❌ Enter a valid withdrawal amount.";
}
else if(balance-amount>=minBalance){
    result.style.background="#d1f7d6";
    result.innerHTML="✅ Withdrawn ₹"+amount+". Balance: ₹"+(balance-amount);
}
else{
    result.style.background="#f8d7da";
    result.innerHTML="❌ Withdrawal denied! Minimum balance must remain ₹"+minBalance;
}
}
</script>

</body>
</html>
