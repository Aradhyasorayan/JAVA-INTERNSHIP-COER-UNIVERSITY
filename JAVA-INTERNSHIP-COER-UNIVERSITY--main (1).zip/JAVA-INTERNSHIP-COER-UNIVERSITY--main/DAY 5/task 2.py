<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-g">

        <meta charset ="UTEF-g">
        <meta name="viewport" content="width=device-width,initial-scale=1.">
<title>Document</title>
</head>
<form id="frm"action="">
    <table>
        <tr>
            <td>Name</td>
           <td> <input type="text" name="myname"></td>
           </tr>
           <tr>
            <td><input type="text" name="mtname"></td>
           </tr>
        <tr>
            <td></td>
            <td><input type="sumit"value="summit"></td>

        </tr>
    </table>
</form>
</body>
<script>
    $(document).ready(function(_){
        rules:{
            myname:{

            },
            myemail:{
                required:true,
                email:true,
            },
            myage:{
                required:true,
                min:18,
                maz:60,
            },

            }
        },
        message:{
            myname:{
                required:"This field is imp",

                }
            }
</script>
</html> -->


<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>


    <script src="jquery-3.7.1.min.js"></script>

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.19.5/jquery.validate.min.js"></script>
</head>

<body>

<form id="frm" action="">
    <table>
        <tr>
            <td>Name</td>
            <td><input type="text" name="myname"></td>
        </tr>

        <tr>
            <td>Email</td>
            <td><input type="text" name="myemail"></td>
        </tr>

        <tr>
            <td>Age</td>
            <td><input type="text" name="myage"></td>
        </tr>

        <tr>
            <td></td>
            <td><input type="submit" value="Submit"></td>
        </tr>
    </table>
</form>
</body>
<script>
$(document).ready(function () {

    $("#frm").validate({

        rules: {
            myname: {
                required : true,
            },

            myemail: {
                required: true,
                email: true,
            },

            myage: {
                required: true,
                min: 18,
                max: 60
            }
        },

        messages: {
            myname: {
                required: "This field is Imp."
            },

            myemail: {
                required: "Please enter your email.",
                email: "Enter a valid email."
            },

            myage: {
                required: "Please enter your age.",
                min: "Age must be at least 18.",
                max: "Age must be less than or equal to 60."
            }
        }

    });

});
</script>

</body>
</html> -->

<!DOCTYPE html>
<html>
<head>
    <title>jQuery Validation</title>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>

    <style>
        label.error{
            color:black;
            margin-left:10px;
        }
    </style>
</head>

<body>

<form id="frm">

<table>

<tr>
    <td>Name</td>
    <td><input type="text" name="myname"></td>
</tr>

<tr>
    <td>Email</td>
    <td><input type="text" name="myemail"></td>
</tr>

<tr>
    <td>Age</td>
    <td><input type="text" name="myage"></td>
</tr>

<tr>
    <td>Password</td>
    <td><input type="password" id="mypassword" name="mypassword"></td>
</tr>

<tr>
    <td>Confirm Password</td>
    <td><input type="password" name="confirmpassword"></td>
</tr>

<tr>
    <td></td>
    <td><input type="submit" value="Submit"></td>
</tr>

</table>

</form>

<script>
$(document).ready(function(){

    $("#frm").validate({

        rules:{
            myname:{
                required:true
            },

            myemail:{
                required:true,
                email:true
            },

            myage:{
                required:true,
                number:true,
                min:18,
                max:60
            },

            mypassword:{
                required:true,
                minlength:6
            },

            confirmpassword:{
                required:true,
                equalTo:"#mypassword"
            }
        },

        messages:{
            myname:{
                required:"This Field is Imp"
            },

            myemail:{
                required:"This field is required.",
                email:"Enter a valid email."
            },

            myage:{
                required:"This field is required.",
                number:"Enter numbers only.",
                min:"Minimum age is 18.",
                max:"Maximum age is 60."
            },

            mypassword:{
                required:"This field is required.",
                minlength:"Password must be at least 6 characters."
            },

            confirmpassword:{
                required:"This field is required.",
                equalTo:"Password does not match."
            }
        }

    });

});
</script>

</body>
</html>
