<!DOCTYPE html>
<html>
<head>
<title>Quiz</title>
</head>

<body>

<h2>Quiz</h2>

<form>

<p>1. What is the capital of India?</p>
<input type="radio" name="q1"> Mumbai<br>
<input type="radio" name="q1"> New Delhi<br>
<input type="radio" name="q1"> Chennai<br>
<input type="radio" name="q1"> Kolkata<br><br>

<p>2. Which planet is called the Red Planet?</p>
<input type="radio" name="q2"> Earth<br>
<input type="radio" name="q2"> Mars<br>
<input type="radio" name="q2"> Venus<br>
<input type="radio" name="q2"> Jupiter<br><br>

<p>3. HTML stands for?</p>
<input type="radio" name="q3"> Hyper Text Markup Language<br>
<input type="radio" name="q3"> Home Tool Markup Language<br>
<input type="radio" name="q3"> High Text Language<br>
<input type="radio" name="q3"> Hyper Transfer Language<br><br>

<p>4. Which is used for web page styling?</p>
<input type="radio" name="q4"> HTML<br>
<input type="radio" name="q4"> CSS<br>
<input type="radio" name="q4"> Java<br>
<input type="radio" name="q4"> Python<br><br>

<p>5. 10 + 20 = ?</p>
<input type="radio" name="q5"> 20<br>
<input type="radio" name="q5"> 30<br>
<input type="radio" name="q5"> 40<br>
<input type="radio" name="q5"> 50<br><br>

<p>6. Which is a programming language?</p>
<input type="radio" name="q6"> Java<br>
<input type="radio" name="q6"> HTML<br>
<input type="radio" name="q6"> CSS<br>
<input type="radio" name="q6"> SQL<br><br>

<p>7. How many days are in a week?</p>
<input type="radio" name="q7"> 5<br>
<input type="radio" name="q7"> 6<br>
<input type="radio" name="q7"> 7<br>
<input type="radio" name="q7"> 8<br><br>

<p>8. Which is the largest animal?</p>
<input type="radio" name="q8"> Elephant<br>
<input type="radio" name="q8"> Blue Whale<br>
<input type="radio" name="q8"> Tiger<br>
<input type="radio" name="q8"> Lion<br><br>

<p>9. Which tag creates a link in HTML?</p>
<input type="radio" name="q9"> &lt;a&gt;<br>
<input type="radio" name="q9"> &lt;p&gt;<br>
<input type="radio" name="q9"> &lt;h1&gt;<br>
<input type="radio" name="q9"> &lt;img&gt;<br><br>

<p>10. Father of Computer?</p>
<input type="radio" name="q10"> Charles Babbage<br>
<input type="radio" name="q10"> Bill Gates<br>
<input type="radio" name="q10"> Steve Jobs<br>
<input type="radio" name="q10"> Alan Turing<br><br>

<center>
<input type="submit" value="Submit">
</center>

</form>

</body>
</html>
