<!DOCTYPE html>
<html>
<head>
    <title>Table of 2</title>
</head>
<body>

<script>
    let num = 2;

    document.write("<h3>Table of " + num + "</h3>");

    for (let i = 1; i <= 10; i++) {
        document.write(num + " * " + i + " = " + (num * i) + "<br>");
    }
</script>

</body>
</html>
