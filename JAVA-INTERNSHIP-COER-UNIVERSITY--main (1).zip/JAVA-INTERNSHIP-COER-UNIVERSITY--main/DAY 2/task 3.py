<!DOCTYPE html>
<html lang="en">
<>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Result</title>

<style>
body{
    font-family: Arial, sans-serif;
    background:#f4f4f4;
}

.container{
    width:500px;
    margin:30px auto;
    background:white;
    padding:20px;
    border:2px solid black;
}

table{
    width:100%;
    border-collapse:collapse;
}

table, th, td{
    border:1px solid black;
}

th,td{
    padding:8px;
}

input{
    width:95%;
    padding:5px;
}

button{
    margin-top:15px;
    padding:10px 20px;
    cursor:pointer;
    font-size:16px;
}

.summary{
    margin-top:20px;
}

.summary th{
    background:#ddd;
}
</style>

</head>
<body>

<div class="container">

<h2 align="center">Student Result</h2>

<table>
<tr>
<td>Student Name</td>
<td><input type="text" id="name"></td>
</tr>

<tr>
<td>Student ID</td>
<td><input type="text" id="id"></td>
</tr>

<tr>
<td>English</td>
<td><input type="number" id="eng"></td>
</tr>

<tr>
<td>Math</td>
<td><input type="number" id="math"></td>
</tr>

<tr>
<td>Physics</td>
<td><input type="number" id="phy"></td>
</tr>

<tr>
<td>Chemistry</td>
<td><input type="number" id="chem"></td>
</tr>

<tr>
<td>Computer Science</td>
<td><input type="number" id="cs"></td>
</tr>

</table>

<center>
<button onclick="result()">Calculate Result</button>
</center>

<table class="summary">

<tr>
<th colspan="2">Result Summary</th>
</tr>

<tr>
<td>Student Name</td>
<td id="rname"></td>
</tr>

<tr>
<td>Student ID</td>
<td id="rid"></td>
</tr>

<tr>
<td>Total Marks</td>
<td id="total"></td>
</tr>

<tr>
<td>Percentage</td>
<td id="per"></td>
</tr>

<tr>
<td>Division</td>
<td id="div"></td>
</tr>

</table>

</div>

<script>

function result(){

let name=document.getElementById("name").value;
let id=document.getElementById("id").value;

let eng=parseFloat(document.getElementById("eng").value)||0;
let math=parseFloat(document.getElementById("math").value)||0;
let phy=parseFloat(document.getElementById("phy").value)||0;
let chem=parseFloat(document.getElementById("chem").value)||0;
let cs=parseFloat(document.getElementById("cs").value)||0;

let total=eng+math+phy+chem+cs;
let percentage=(total/500)*100;

let division="";

if(percentage>=60)
division="First Division";
else if(percentage>=45)
division="Second Division";
else if(percentage>=33)
division="Third Division";
else
division="Fail";

document.getElementById("rname").innerHTML=name;
document.getElementById("rid").innerHTML=id;
document.getElementById("total").innerHTML=total+"/500";
document.getElementById("per").innerHTML=percentage.toFixed(2)+"%";
document.getElementById("div").innerHTML=division;

}

</script>

</body>
</html>
