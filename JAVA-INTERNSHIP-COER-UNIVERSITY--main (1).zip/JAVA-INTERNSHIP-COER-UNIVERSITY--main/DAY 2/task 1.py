<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Form</title>

<style>
body{
    margin:0;
    padding:0;
    font-family: "Times New Roman", serif;
    background:#ffffff;
}

.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

table{
    font-size:35px;
}

input[type=text],
input[type=password]{
    width:230px;
    height:30px;
    font-size:20px;
}

button{
    width:240px;
    height:48px;
    background:#3f4652;
    color:white;
    border:none;
    font-size:22px;
    cursor:pointer;
}

button:hover{
    background:#2f3640;
}
</style>

<script>
function checkLogin(){

    let username=document.getElementById("username").value;
    let password=document.getElementById("password").value;

    if(username=="" || password==""){
        alert("Please enter Username and Password");
    }
    else{
        alert("Success");
    }

}
</script>

</head>
<body>

<div class="container">

<table>
<tr>
<td>Username</td>
<td>
<input type="text" id="username">
</td>
</tr>

<tr>
<td>Password</td>
<td>
<input type="password" id="password">
</td>
</tr>

<tr>
<td></td>
<td>
<button onclick="checkLogin()">submit</button>
</td>
</tr>

</table>

</div>

</body>
</html>
