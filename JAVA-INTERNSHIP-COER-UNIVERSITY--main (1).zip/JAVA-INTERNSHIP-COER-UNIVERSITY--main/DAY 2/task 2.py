<!-- <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Calculator</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

body{
    display:flex;
    justify-content:flex-start;
    align-items:flex-start;
    padding:50px;
    background:#fff;
}

.calculator{
    width:360px;
    border:2px solid #555;
    padding:10px;
}

#display{
    width:100%;
    height:55px;
    font-size:35px;
    padding:5px 10px;
    margin-bottom:10px;
    border:2px solid #555;
    outline:none;
}

.buttons{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:10px;
}

button{
    height:70px;
    font-size:35px;
    border:2px solid #555;
    background:white;
    cursor:pointer;
}

button:hover{
    background:#ddd;
}
</style>
</head>

<body>

<div class="calculator">

<input type="text" id="display" readonly>

<div class="buttons">

<button onclick="addValue('1')">1</button>
<button onclick="addValue('2')">2</button>
<button onclick="addValue('3')">3</button>
<button onclick="addValue('4')">4</button>

<button onclick="addValue('5')">5</button>
<button onclick="addValue('6')">6</button>
<button onclick="addValue('7')">7</button>
<button onclick="addValue('8')">8</button>

<button onclick="addValue('9')">9</button>
<button onclick="addValue('0')">0</button>
<button onclick="clearDisplay()">C</button>
<button onclick="calculate()">=</button>

<button onclick="addValue('+')">+</button>
<button onclick="addValue('-')">-</button>
<button onclick="addValue('*')">*</button>
<button onclick="addValue('/')">/</button>

</div>

</div>

<script>

function addValue(value){
    document.getElementById("display").value += value;
}

function clearDisplay(){
    document.getElementById("display").value = "";
}

function calculate(){
    try{
        document.getElementById("display").value =
        eval(document.getElementById("display").value);
    }
    catch{
        document.getElementById("display").value = "Error";
    }
}

</script>

</body>
</html> -->

<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
    <style>
        body{
            font-family: Arial, sans-serif;
        }

        .calculator{
            width: 250px;
            border: 2px solid black;
            padding: 10px;
            margin: 30px;
        }

        #display{
            width: 95%;
            height: 40px;
            font-size: 22px;
            margin-bottom: 10px;
            text-align: right;
        }

        table{
            width:100%;
        }

        button{
            width:50px;
            height:45px;
            font-size:22px;
            margin:5px;
            cursor:pointer;
        }
    </style>
</head>
<body>

<div class="calculator">
    <input type="text" id="display" readonly>

    <table>
        <tr>
            <td><button onclick="addValue('1')">1</button></td>
            <td><button onclick="addValue('2')">2</button></td>
            <td><button onclick="addValue('3')">3</button></td>
            <td><button onclick="addValue('4')">4</button></td>
        </tr>

        <tr>
            <td><button onclick="addValue('5')">5</button></td>
            <td><button onclick="addValue('6')">6</button></td>
            <td><button onclick="addValue('7')">7</button></td>
            <td><button onclick="addValue('8')">8</button></td>
        </tr>

        <tr>
            <td><button onclick="addValue('9')">9</button></td>
            <td><button onclick="addValue('0')">0</button></td>
            <td><button onclick="clearDisplay()">C</button></td>
            <td><button onclick="calculate()">=</button></td>
        </tr>

        <tr>
            <td><button onclick="addValue('+')">+</button></td>
            <td><button onclick="addValue('-')">-</button></td>
            <td><button onclick="addValue('*')">*</button></td>
            <td><button onclick="addValue('/')">/</button></td>
        </tr>
    </table>
</div>

<script>
function addValue(value){
    document.getElementById("display").value += value;
}

function clearDisplay(){
    document.getElementById("display").value = "";
}

function calculate(){
    let exp = document.getElementById("display").value;
    try{
        document.getElementById("display").value = eval(exp);
    }
    catch{
        document.getElementById("display").value = "Error";
    }
}
</script>

</body>
</html>
