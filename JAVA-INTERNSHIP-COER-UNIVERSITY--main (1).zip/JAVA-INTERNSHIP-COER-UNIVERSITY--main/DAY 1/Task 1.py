<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-g">

        <meta charset ="UTEF-g">
        <meta name="viewport" content="width=device-width,initial-scale=1.">
<title>Document</title>
</head>
<body>
 <script>
document.write("Hello");
 </script> 
 </body>

</html>
