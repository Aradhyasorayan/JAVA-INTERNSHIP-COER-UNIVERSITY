<!DOCTYPE html>
<html>
<head>
    <title>Stopwatch</title>
    <style>
        body{
            font-family:Arial;
            text-align:center;
            margin-top:100px;
            background:#f0f0f0;
        }
        #time{
            font-size:50px;
            margin:20px;
            color:#333;
        }
        button{
            padding:10px 20px;
            margin:5px;
            font-size:18px;
            cursor:pointer;
            border:none;
            border-radius:5px;
        }
        
    </style>
</head>
<body>

<h1>Stopwatch</h1>

<div id="time">00:00:00</div>

<button class="start" onclick="start()">Start</button>
<button class="stop" onclick="stop()">Stop</button>
<button class="reset" onclick="reset()">Reset</button>

<script>
let sec = 0;
let min = 0;
let hr = 0;
let timer;

function update() {
    sec++;
    if(sec==60){
        sec=0;
        min++;
    }
    if(min==60){
        min=0;
        hr++;
    }

    document.getElementById("time").innerHTML =
        (hr<10?"0":"")+hr + ":" +
        (min<10?"0":"")+min + ":" +
        (sec<10?"0":"")+sec;
}

function start(){
    if(!timer){
        timer = setInterval(update,1000);
    }
}

function stop(){
    clearInterval(timer);
    timer = null;
}

function reset(){
    stop();
    hr = 0;
    min = 0;
    sec = 0;
    document.getElementById("time").innerHTML = "00:00:00";
}
</script>

</body>
</html>
