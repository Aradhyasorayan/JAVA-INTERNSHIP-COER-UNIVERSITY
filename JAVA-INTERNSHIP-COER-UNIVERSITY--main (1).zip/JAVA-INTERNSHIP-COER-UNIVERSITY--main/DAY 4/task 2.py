<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tic Tac Toe Game</title>

<style>
body{
    font-family: "Times New Roman", serif;
    text-align:center;
    margin-top:40px;
}

h1{
    margin-bottom:20px;
}

#turn{
    font-size:28px;
    font-weight:bold;
    margin-bottom:20px;
}

table{
    margin:auto;
    border-collapse:collapse;
}

td{
    width:100px;
    height:100px;
    border:2px solid black;
    font-size:45px;
    text-align:center;
    cursor:pointer;
}

button{
    margin-top:20px;
    padding:10px 20px;
    font-size:18px;
}
</style>

</head>
<body>

<h1>Tic Tac Toe Game</h1>

<div id="turn">Turn : X</div>

<table>
<tr>
<td onclick="play(this)"></td>
<td onclick="play(this)"></td>
<td onclick="play(this)"></td>
</tr>

<tr>
<td onclick="play(this)"></td>
<td onclick="play(this)"></td>
<td onclick="play(this)"></td>
</tr>

<tr>
<td onclick="play(this)"></td>
<td onclick="play(this)"></td>
<td onclick="play(this)"></td>
</tr>
</table>

<button onclick="resetGame()">Reset Game</button>

<script>

let currentPlayer = "X";

function play(cell){

if(cell.innerHTML!="")
return;

cell.innerHTML=currentPlayer;

if(checkWinner()){
setTimeout(()=>{
alert(currentPlayer+" Wins!");
resetGame();
},100);
return;
}

if(isDraw()){
setTimeout(()=>{
alert("Match Draw!");
resetGame();
},100);
return;
}

currentPlayer=(currentPlayer=="X")?"O":"X";
document.getElementById("turn").innerHTML="Turn : "+currentPlayer;

}

function checkWinner(){

let cells=document.getElementsByTagName("td");

let win=[
[0,1,2],
[3,4,5],
[6,7,8],
[0,3,6],
[1,4,7],
[2,5,8],
[0,4,8],
[2,4,6]
];

for(let i=0;i<win.length;i++){

let a=win[i][0];
let b=win[i][1];
let c=win[i][2];

if(cells[a].innerHTML!="" &&
cells[a].innerHTML==cells[b].innerHTML &&
cells[b].innerHTML==cells[c].innerHTML)
return true;
}

return false;
}

function isDraw(){

let cells=document.getElementsByTagName("td");

for(let i=0;i<cells.length;i++){
if(cells[i].innerHTML=="")
return false;
}

return true;
}

function resetGame(){

let cells=document.getElementsByTagName("td");

for(let i=0;i<cells.length;i++){
cells[i].innerHTML="";
}

currentPlayer="X";
document.getElementById("turn").innerHTML="Turn : X";

}

</script>

</body>
</html>
