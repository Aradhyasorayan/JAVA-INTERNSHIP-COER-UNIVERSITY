<!DOCTYPE html>
<html>
<head>
    <title>Document</title>

    <script>
        function showMessage() {
            alert("You clicked on this");
        }
    </script>

    <style>
        body {
            font-family: "Times New Roman", serif;
            margin: 20px;
        }

        p {
            font-size: 28px;
            margin: 20px 0;
        }

        .red {
            color: red;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <button onclick="showMessage()">click</button>

    <p>Himanshu</p>
    <p>Aryan</p>
    <p class="red">Satyam

</body>
</html>
