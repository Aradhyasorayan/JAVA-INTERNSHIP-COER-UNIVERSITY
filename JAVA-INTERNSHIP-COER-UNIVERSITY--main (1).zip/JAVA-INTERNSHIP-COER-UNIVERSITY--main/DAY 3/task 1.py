<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-g">

        <meta charset ="UTEF-g">
        <meta name="viewport" content="width=device-width,initial-scale=1.">
<title>Document</title>
<script> src= c:\Users\hr610\Downloads\jquery-4.0.0.min.js"></script>
</head>
<body>
 </body>
<script>
    $(document).ready(function(){
        alert("hello");
    });
</script>
</html>
