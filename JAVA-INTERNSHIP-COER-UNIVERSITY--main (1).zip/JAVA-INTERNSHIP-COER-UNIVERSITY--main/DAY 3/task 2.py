<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JavaScript Class Methods</title>

<style>
body{
    font-family: Arial, sans-serif;
    text-align:center;
    margin-top:40px;
}

#box{
    width:350px;
    height:350px;
    background:red;
    margin:20px auto;
    transition:0.5s;
}

/* Class to be added */
.active{
    background:rgb(0, 64, 255) !important;
    border-radius:20px;
    transform:rotate(5deg) scale(1.05);
    box-shadow:0 0 20px gray;
}

/* Border class */
.border{
    border:8px solid black;
}

button{
    padding:10px 15px;
    font-size:16px;
    margin:5px;
    cursor:pointer;
}
</style>
</head>

<body>

<div id="box"></div>

<button onclick="startMethod()">Start Chains of Method</button>
<button onclick="addBorder()">Add Border</button>
<br><br>

<button onclick="addClass()">Add Class</button>
<button onclick="removeClass()">Remove Class</button>
<button onclick="toggleClass()">Toggle Class</button>

<script>

const box = document.getElementById("box");

// Method chaining example
function startMethod(){
    box.style.background="deeppink";
    box.style.borderRadius="15px";
    box.style.boxShadow="0 0 20px gray";
    box.style.transform="rotate(5deg)";
}

// Add border
function addBorder(){
    box.classList.add("border");
}

// Add class
function addClass(){
    box.classList.add("active");
}

// Remove class
function removeClass(){
    box.classList.remove("active");
}

// Toggle class
function toggleClass(){
    box.classList.toggle("active");
}

</script>

</body>
</html>
