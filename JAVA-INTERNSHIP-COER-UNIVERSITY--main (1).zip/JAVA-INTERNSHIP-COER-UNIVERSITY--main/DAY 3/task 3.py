<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>jQuery Effects Demo</title>

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <style>
        body{
            font-family: Arial, sans-serif;
            margin:20px;
        }

        #box{
            width:500px;
            height:500px;
            background:red;
            margin-bottom:10px;
        }

        button{
            padding:8px 15px;
            margin:3px;
            font-size:16px;
            cursor:pointer;
        }
    </style>
</head>
<body>

<div id="box"></div>

<button id="hide">hide</button>
<button id="show">Show</button>
<button id="toggle">toggle</button>
<button id="slideup">slideup</button>
<button id="slidedown">slidedown</button>
<button id="slidetoggle">slidetoggle</button>
<button id="fadein">fadein</button>
<button id="fadeout">fadeout</button>
<button id="fadetoggle">fadetoggle</button>

<script>

$(document).ready(function(){

    $("#hide").click(function(){
        $("#box").hide();
    });

    $("#show").click(function(){
        $("#box").show();
    });

    $("#toggle").click(function(){
        $("#box").toggle();
    });

    $("#slideup").click(function(){
        $("#box").slideUp();
    });

    $("#slidedown").click(function(){
        $("#box").slideDown();
    });

    $("#slidetoggle").click(function(){
        $("#box").slideToggle();
    });

    $("#fadein").click(function(){
        $("#box").fadeIn();
    });

    $("#fadeout").click(function(){
        $("#box").fadeOut();
    });

    $("#fadetoggle").click(function(){
        $("#box").fadeToggle();
    });

});

</script>

</body>
</html>
